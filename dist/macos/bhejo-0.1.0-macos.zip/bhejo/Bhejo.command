#!/bin/bash
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Bhejo needs Node.js 18.17 or newer."
  echo "  Install it from https://nodejs.org, then double-click this file again."
  echo ""
  read -r -p "  Press return to close."
  exit 1
fi

echo "  Starting Bhejo. Keep this window open while you send or receive."
node bin/bhejo.mjs receive "$@" &
sleep 2
open "http://127.0.0.1:53318" 2>/dev/null || echo "  Open http://127.0.0.1:53318 in your browser."
wait
