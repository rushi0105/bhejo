#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "Bhejo needs Node.js 18.17 or newer: https://nodejs.org"
  exit 1
fi

echo "Bhejo is starting. Open http://127.0.0.1:53318 in your browser."
exec node bin/bhejo.mjs receive "$@"
