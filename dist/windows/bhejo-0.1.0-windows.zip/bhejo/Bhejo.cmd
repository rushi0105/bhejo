@echo off
title Bhejo
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Bhejo needs Node.js 18.17 or newer.
  echo   Install it from https://nodejs.org and run this file again.
  echo.
  pause
  exit /b 1
)

echo   Starting Bhejo. Keep this window open while you send or receive.
start "Bhejo" cmd /k node "%~dp0bin\bhejo.mjs" receive %*
timeout /t 3 >nul
start "" "http://127.0.0.1:53318"
exit /b 0
